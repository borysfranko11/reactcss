---
id: activating-classes
title: Activating Classes

---
